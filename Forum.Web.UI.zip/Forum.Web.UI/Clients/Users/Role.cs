﻿namespace Forum.Web.UI.Clients.Users
{
    public enum Role
    {
        User,
        Admin,
    }
}

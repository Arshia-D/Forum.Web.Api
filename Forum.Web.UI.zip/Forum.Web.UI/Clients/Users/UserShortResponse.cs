﻿namespace Forum.Web.UI.Clients.Users
{
    public class UserShortResponse
    {
        public long? Id { get; set; }
        public string? Username { get; set; }
        public string? FullName { get; set; }
    }
}

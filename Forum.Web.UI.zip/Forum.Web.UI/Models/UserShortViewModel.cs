﻿namespace Forum.Web.UI.Models
{
    public class UserShortViewModel
    {
        public long? Id { get; set; }
        public string? Username { get; set; }
        public string? FullName { get; set; }
    }
}
